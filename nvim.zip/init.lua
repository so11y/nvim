require("config.options")
require("config.keymaps")
require("config.lazy")