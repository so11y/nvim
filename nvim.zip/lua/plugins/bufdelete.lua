return {
    -- 这是一个专门优化“关闭标签”体验的插件
    {
        "famiu/bufdelete.nvim",
        event = "VeryLazy",
    }
}