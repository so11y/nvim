return {
    "hrsh7th/nvim-cmp",
    dependencies = {
        "hrsh7th/cmp-nvim-lsp", -- LSP 补全源
        "hrsh7th/cmp-buffer",   -- 缓冲区补全源
        "hrsh7th/cmp-path",     -- 路径补全源
    },
    event = "InsertEnter",
    config = function()
        local cmp = require("cmp")

        cmp.setup({
            completion = {
                completeopt = "menu,menuone,noinsert",
                max_items = 20,
            },
            sources = {
                { name = "nvim_lsp", priority = 100 },
                { name = "buffer", priority = 80, keyword_length = 3 },
                { name = "path", priority = 60 },
            },
            mapping = {
                ["<A-j>"] = cmp.mapping.select_next_item(),
                ["<A-k>"] = cmp.mapping.select_prev_item(),
                ["<CR>"] = cmp.mapping.confirm({ select = true }),
                ["<C-n>"] = cmp.mapping.select_next_item(),
                ["<C-p>"] = cmp.mapping.select_prev_item(),
                ["<C-e>"] = cmp.mapping.abort(),
                ["<C-Space>"] = cmp.mapping.complete(),
            },
            formatting = {
                format = function(entry, vim_item)
                    return vim_item
                end,
            },
            experimental = {
                ghost_text = true,
            },
        })
    end,
}
