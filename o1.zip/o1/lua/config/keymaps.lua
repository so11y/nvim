vim.g.mapleader = ' '

--if vim.g.neovide then
    -- Command + S -> 保存文件
    vim.api.nvim_set_keymap('n', '<A-s>', ':w<CR>', {
        noremap = true,
        silent = true
    })

    vim.api.nvim_set_keymap('n', '<A-s>', ':w<CR>', {
        noremap = true,
        silent = true
    })
    -- 插入模式下保存
    vim.api.nvim_set_keymap('i', '<A-s>', '<Esc>:w<CR>a', {
        noremap = true,
        silent = true
    })

    vim.api.nvim_set_keymap('v', '<A-s>', ':w<CR>', {
        noremap = true,
        silent = true
    }) -- Visual 模式下也保存

    -- Command + A -> 全选
    vim.api.nvim_set_keymap('n', '<A-a>', 'ggVG', {
        noremap = true,
        silent = true
    })
    vim.api.nvim_set_keymap('v', '<A-a>', 'ggVG', {
        noremap = true,
        silent = true
    }) -- Visual 模式下也全选

    -- Command + Z -> 撤销
    vim.api.nvim_set_keymap('n', '<A-z>', 'u', {
        noremap = true,
        silent = true
    })
    vim.api.nvim_set_keymap('v', '<A-z>', 'u', {
        noremap = true,
        silent = true
    }) -- Visual 模式下也撤销
    vim.api.nvim_set_keymap('i', '<A-z>', '<Esc>ua', {
        noremap = true,
        silent = true
    })

    -- Command + X -> 剪切
    vim.api.nvim_set_keymap('n', '<A-x>', 'dd', {
        noremap = true,
        silent = true
    })
    vim.api.nvim_set_keymap('v', '<A-x>', 'd', {
        noremap = true,
        silent = true
    }) -- Visual 模式下剪切

    -- Command + C -> 复制
    vim.api.nvim_set_keymap('n', '<A-c>', 'yy', {
        noremap = true,
        silent = true
    })
    vim.api.nvim_set_keymap('v', '<A-c>', 'y', {
        noremap = true,
        silent = true
    }) -- Visual 模式下复制

    -- Command + V -> 粘贴
    vim.api.nvim_set_keymap('n', '<A-v>', 'p', {
        noremap = true,
        silent = true
    })
    vim.api.nvim_set_keymap('v', '<A-v>', 'p', {
        noremap = true,
        silent = true
    }) -- Visual 模式下粘贴
    vim.keymap.set('i', '<A-v>', '<Esc>"+pa', {
        noremap = true,
        silent = true
    })

    -- 使用 Alt + A 删除当前行
    vim.api.nvim_set_keymap('n', '<A-d>', 'dd', {
        noremap = true,
        silent = true
    })

    -- Shift + J -> 向下滚动半屏
    vim.keymap.set({'n', 'v'}, '<S-J>', '<C-d>', {
        noremap = true,
        silent = true
    })

    -- Shift + K -> 向上滚动半屏
    vim.keymap.set({'n', 'v'}, '<S-K>', '<C-u>', {
        noremap = true,
        silent = true
    })

    -- Command + Y -> Redo
    vim.api.nvim_set_keymap('n', '<A-y>', '<C-r>', {
        noremap = true,
        silent = true
    })

    -- gl -> 跳转到当前行最右边
    vim.api.nvim_set_keymap('n', 'gl', '$', {
        noremap = true,
        silent = true
    })

    -- gd -> 跳转到当前行最左边
    vim.api.nvim_set_keymap('n', 'gh', '0', {
        noremap = true,
        silent = true
    })

    -- Command + U -> 跳转到上一次的光标位置
    vim.api.nvim_set_keymap('n', '<A-u>', '<C-o>', {
        noremap = true,
        silent = true
    })

    -- 将回车键（Enter）映射为进入插入模式
    vim.api.nvim_set_keymap('n', '<CR>', 'a', {
        noremap = true,
        silent = true
    })

    vim.api.nvim_set_keymap('v', '<CR>', 'a', {
        noremap = true,
        silent = true
    })

    -- 切换到下一个标签
    vim.keymap.set('n', '<A-l>', ':BufferLineCycleNext<CR>', {
        noremap = true,
        silent = true
    })
    -- 切换到上一个标签
    vim.keymap.set('n', '<A-h>', ':BufferLineCyclePrev<CR>', {
        noremap = true,
        silent = true
    })
    -- 提示保存后再关闭
    vim.api.nvim_set_keymap('n', '<A-w>', ':confirm bdelete<CR>', {
        noremap = true,
        silent = true
    })

    -- 水平分屏
    vim.keymap.set('n', '<leader>sh', ':split<CR>', {
        noremap = true,
        silent = true
    })
    -- 垂直分屏
    vim.keymap.set('n', '<leader>sv', ':vsplit<CR>', {
        noremap = true,
        silent = true
    })
    -- 关闭分屏
    vim.keymap.set('n', '<leader>sc', '<C-w>c', {
        noremap = true,
        silent = true
    })
    -- 只保留当前分屏
    vim.keymap.set('n', '<leader>so', '<C-w>o', {
        noremap = true,
        silent = true
    })

    vim.api.nvim_set_keymap('n', '<leader>vs', ':vsplit<CR>', {
        noremap = true,
        silent = true
    })
    vim.api.nvim_set_keymap('n', '<leader>hs', ':split<CR>', {
        noremap = true,
        silent = true
    })

    vim.api.nvim_set_keymap('n', '<C-h>', '<C-w>h', {
        noremap = true,
        silent = true
    })
    vim.api.nvim_set_keymap('n', '<C-j>', '<C-w>j', {
        noremap = true,
        silent = true
    })
    vim.api.nvim_set_keymap('n', '<C-k>', '<C-w>k', {
        noremap = true,
        silent = true
    })
    vim.api.nvim_set_keymap('n', '<C-l>', '<C-w>l', {
        noremap = true,
        silent = true
    })

--end
