return {{
    "which-key.nvim",
    enabled = false
}}
